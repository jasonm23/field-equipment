package com.opsmanager.fieldequipment.core;

public class IntentFactory {
    //TODO implement an Activity and Fragment delegate pattern
}

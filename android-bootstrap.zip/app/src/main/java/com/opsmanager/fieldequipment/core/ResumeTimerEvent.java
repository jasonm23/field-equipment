package com.opsmanager.fieldequipment.core;

/**
 * Marker class for resuming a timer through Otto
 */
public class ResumeTimerEvent {
}

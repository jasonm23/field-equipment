package com.opsmanager.fieldequipment.core;

/**
 * Marker class for Otto for a pause event for the timer.
 */
public class PauseTimerEvent {
}
